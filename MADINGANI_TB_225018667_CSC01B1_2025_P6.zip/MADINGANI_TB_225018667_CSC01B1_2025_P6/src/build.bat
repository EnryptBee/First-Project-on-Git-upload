@echo off
REM Dr SP Sithungu
REM P4 Solution Batch File
REM 15 August 2025

REM Create directories if they don't exist
if not exist "..\bin" mkdir "..\bin"
if not exist "..\docs" mkdir "..\docs"
if not exist "..\output" mkdir "..\output"

echo Compiling source files...

REM Compile each source file into object files
g++ --std=c++20 -fmodules-ts -c LibUtility.cpp
g++ --std=c++20 -fmodules-ts -c UJImage.cpp
g++ --std=c++20 -fmodules-ts -c FlagIllustrator.cpp
g++ --std=c++20 -fmodules-ts -c ColourIllustrator.cpp
g++ --std=c++20 -fmodules-ts -c BWIllustrator.cpp
g++ --std=c++20 -fmodules-ts -c GrayscaleIllustrator.cpp
g++ --std=c++20 -fmodules-ts -c main.cpp

REM Link object files into executable
g++ LibUtility.o UJImage.o FlagIllustrator.o BWIllustrator.o GrayscaleIllustrator.o ColourIllustrator.o main.o -o ..\bin\prog.exe

if ERRORLEVEL 1 (
    echo Build failed! Exiting batch.
    pause
    exit /b 1
)

echo Cleaning up object files...
del *.o
rmdir /s /q gcm.cache

REM Run tests
echo Testing Austria flag generation...
..\bin\prog.exe 0 > ..\output\image_au.ppm

echo Testing Japan flag generation...
..\bin\prog.exe 1 > ..\output\image_jp.ppm

echo Testing Nigeria flag generation...
..\bin\prog.exe 2 > ..\output\image_ng.ppm

echo Images exported successfully.
pause
 module;

#include <sstream>
#include <string>

export module GrayscaleIllustrator;

import LibUtility;
import FlagIllustrator;

export class GrayscaleIllustrator: public FlagIllustrator{
public:
    GrayscaleIllustrator() : FlagIllustrator(){}
	
    GrayscaleIllustrator (int intHeight, int intWidth) : FlagIllustrator(intHeight, intWidth) {};
	inline ~GrayscaleIllustrator() = default;

    std::string illustrate(FlagType eType) override; //ovveride illustate 
	
	std::string exportImage() const;


private:
    int average(UJPixel recPixel) const{
	
    return (recPixel.intRed+recPixel.intGreen+recPixel.intBlue)/3;
	}
};

//GrayscaleIllustrator::GrayscaleIllustrator():FlagIllustrator(){}
//GrayscaleIllustrator::GrayscaleIllustrator(int h,int w):FlagIllustrator(h,w){}

std::string GrayscaleIllustrator::illustrate(FlagType eType) {
    // Draw the flag in color using base class logic
    FlagIllustrator::illustrate(eType);

    // Convert the image pixels to grayscale in-place
    for(int r = 0; r < _image->getHeight(); r++){
        for(int c = 0; c < _image->getWidth(); c++){
            UJPixel p = _image->getPixel(r,c);
            int gray = (p.intRed + p.intGreen+ p.intBlue)/3; // calculate average
            _image->setPixel(r,c, UJPixel{gray, gray, gray});
        }
    }

    return "Grayscale Flag drawn successfully";
}

std::string GrayscaleIllustrator::exportImage() const {
    std::stringstream ss;
    ss<<"P2\n"<<_image->getWidth()<<" "<<_image->getHeight()<<"\n255\n";
    for(int r=0;r<_image->getHeight();r++){
        for(int c=0;c<_image->getWidth();c++){
			UJPixel p =_image->getPixel(r,c);
            int gray = (p.intRed + p.intGreen+ p.intBlue)/3; // grayscale value
            ss<<gray<<" ";
        }
        ss<<"\n";
    }
    return ss.str();
}

//int GrayscaleIllustrator::average(UJPixel recPixel) const {
    //return (recPixel.intRed+recPixel.intGreen+recPixel.intBlue)/3;
//}

#include <cstdlib>
#include <iostream>
#include <fstream>

import LibUtility;
import FlagIllustrator;
import BWIllustrator;
import ColourIllustrator;
import GrayscaleIllustrator;

int main() {
    int modes[] = {0, 1, 2};  // 0=Color, 1=BW, 2=Grayscale
    std::string modeNames[] = {"color", "bw", "grey"};
    FlagType flags[] = {AUSTRIA, JAPAN, NIGERIA};
    std::string flagNames[] = {"austria", "japan", "nigeria"};

    for (int m = 0; m < 3; ++m) {
        for (int f = 0; f < 3; ++f) {
            FlagIllustrator* illustrator = nullptr;
            std::string filename;

            // Create appropriate illustrator
            switch (modes[m]) {
                case 0: illustrator = new ColourIllustrator(300, 500); filename = "color_" + flagNames[f] + ".ppm"; break;
                case 1: illustrator = new BWIllustrator(300, 500); filename = "bw_" + flagNames[f] + ".pbm"; break;
                case 2: illustrator = new GrayscaleIllustrator(300, 500); filename = "grey_" + flagNames[f] + ".pgm"; break;
            }

            // Draw the flag
            illustrator->illustrate(flags[f]);

            // Write to file
            std::ofstream outFile(filename);
            if (!outFile) {
                std::cerr << "Failed to open file: " << filename << std::endl;
                delete illustrator;
                continue;
            }

            outFile << illustrator->exportImage();
            outFile.close();

            std::cout << "Generated " << filename << std::endl;
            delete illustrator;
        }
    }

    std::cout << "All flags generated successfully." << std::endl;
    return 0;
}
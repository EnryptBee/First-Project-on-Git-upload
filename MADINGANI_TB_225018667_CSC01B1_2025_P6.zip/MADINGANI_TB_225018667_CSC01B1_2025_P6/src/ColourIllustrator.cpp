module;

#include <sstream>
#include <cmath>

export module ColourIllustrator;
import LibUtility;
import FlagIllustrator;

export class ColourIllustrator : public FlagIllustrator {

public:
    // Constructors
    ColourIllustrator();              // Default size
    ColourIllustrator(int h, int w);  // Custom size
    ~ColourIllustrator() override = default;

    // Generate the flag based on type (AUSTRIA, JAPAN, NIGERIA)
    std::string illustrate(FlagType eType) override;

    // Export the current image as a PPM color image
    std::string exportImage() const override;

private:
    // Helper functions to draw specific flags
    void drawAuFlag();   // Horizontal red-white-red
    void drawJPFlag();   // White with red circle
    void drawNGFlag();   // Vertical green-white-green
};

//  Constructors 
ColourIllustrator::ColourIllustrator() : FlagIllustrator() {}
ColourIllustrator::ColourIllustrator(int h,int w) : FlagIllustrator(h,w) {}

// Illustrate Flag 
// Chooses which flag to draw based on FlagType
std::string ColourIllustrator::illustrate(FlagType eType) {
    switch(eType) {
        case FlagType::AUSTRIA: drawAuFlag(); break;
        case FlagType::JAPAN:   drawJPFlag(); break;
        case FlagType::NIGERIA: drawNGFlag(); break;
        default: return "Unknown flag type";
    }
    return "Color Flag drawn successfully";
}

// Converts _image pixels to P3 PPM color format
std::string ColourIllustrator::exportImage() const {
    std::stringstream ss;
    ss << "P3\n" << _image->getWidth() << " " << _image->getHeight() << "\n255\n";

    for(int r=0;r<_image->getHeight();r++){
        for(int c=0;c<_image->getWidth();c++){
            UJPixel pixel = _image->getPixel(r,c);
            ss << pixel.intRed << " " << pixel.intGreen << " " << pixel.intBlue << " ";
        }
        ss << "\n";
    }
    return ss.str();
}

//Draw Austria 
// Horizontal stripes: red-white-red
void ColourIllustrator::drawAuFlag() {
    int h = _image->getHeight();
    int w = _image->getWidth();
    for(int r=0;r<h;r++){
        for(int c=0;c<w;c++){
            if(r<h/3 || r>=2*h/3)
                _image->setPixel(r,c,{255,0,0});   // The red part 
            else
                _image->setPixel(r,c,{255,255,255}); // The white 
        }
    }
}

//  Draw Japan
// White background with red circle in the center
void ColourIllustrator::drawJPFlag() {
    int h = _image->getHeight();
    int w = _image->getWidth();
    int cx = w/2, cy = h/2;
    int radius = std::min(h,w)/5;  // Circle radius

    for(int r=0;r<h;r++){
        for(int c=0;c<w;c++){
            int dr = r-cy, dc = c-cx;
            if(dr*dr + dc*dc <= radius*radius)
                _image->setPixel(r,c,{255,0,0});   // Drawig the red circle 
            else
                _image->setPixel(r,c,{255,255,255}); // drawing thw white background 
        }
    }
}

// Draw Nigeria
// The vertical green -white green 
void ColourIllustrator::drawNGFlag() {
    int h = _image->getHeight();
    int w = _image->getWidth();
    int third = w/3;  // Width of each vertical stripe

    for(int r=0;r<h;r++){
        for(int c=0;c<w;c++){
            if(c<third || c>=2*third)
                _image->setPixel(r,c,{0,255,0});     // generating the green part 
            else 
                _image->setPixel(r,c,{255,255,255}); // DRAWING THE WHITE 
        }
    }
}
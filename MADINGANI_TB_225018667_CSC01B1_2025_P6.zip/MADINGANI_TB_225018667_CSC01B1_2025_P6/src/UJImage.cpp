module;

#include <cassert>
#include <iostream>
#include <sstream>
#include <string>

export module UJImage;

import LibUtility;

using Row = UJPixel*;
using Grid = Row*;

export class UJImage {
public:
    UJImage();
    UJImage(int intRows, int intCols);
    UJImage(const UJImage& objOriginal);
    ~UJImage();

    std::string toPPM() const;

    int getHeight() const;
    int getWidth() const;
    UJPixel getPixel(int intRow, int intCol) const;
    void setPixel(int intRow, int intCol, UJPixel recPixel);

    static constexpr int DEFAULT_ROWS = 2;
    static constexpr int DEFAULT_COLS = 2;
    static constexpr UJPixel DEFAULT_PIXEL = {255,255,255};

private:
    void alloc(int intRows, int intCols);
    void clone(const UJImage& objOriginal);
    void dealloc();
    void enforceRange(int intValue,int intMin,int intMax) const;

    Grid _image;
    int _rows;
    int _cols;
};

// constructors
UJImage::UJImage() : UJImage(DEFAULT_ROWS,DEFAULT_COLS) {}
UJImage::UJImage(int intRows,int intCols){ alloc(intRows,intCols); }
UJImage::UJImage(const UJImage& objOriginal)
    : UJImage(objOriginal._rows,objOriginal._cols){ clone(objOriginal); }
UJImage::~UJImage(){ dealloc(); }

std::string UJImage::toPPM() const {
    std::stringstream ss;
    ss << "P3\n" << _cols << " " << _rows << "\n255\n";
    for(int r=0;r<_rows;r++){
        for(int c=0;c<_cols;c++){
            ss<<_image[r][c].intRed<<" "<<_image[r][c].intGreen<<" "<<_image[r][c].intBlue<<" ";
        }
        ss<<"\n";
    }
    return ss.str();
}

void UJImage::alloc(int intRows,int intCols){
    _rows=intRows; _cols=intCols;
    _image=new Row[_rows];
    for(int r=0;r<_rows;r++){
        _image[r]=new UJPixel[_cols];
        for(int c=0;c<_cols;c++) _image[r][c]=DEFAULT_PIXEL;
    }
}

void UJImage::clone(const UJImage& objOriginal){
    for(int r=0;r<_rows;r++)
        for(int c=0;c<_cols;c++)
            _image[r][c]=objOriginal._image[r][c];
}

void UJImage::dealloc(){
    for(int r=0;r<_rows;r++) delete[] _image[r];
    delete[] _image;
}

int UJImage::getHeight() const { return _rows; }
int UJImage::getWidth() const { return _cols; }

UJPixel UJImage::getPixel(int intRow,int intCol) const {
    enforceRange(intRow,0,_rows-1);
    enforceRange(intCol,0,_cols-1);
    return _image[intRow][intCol];
}

void UJImage::setPixel(int intRow,int intCol,UJPixel recPixel){
    enforceRange(intRow,0,_rows-1);
    enforceRange(intCol,0,_cols-1);
    enforceRange(recPixel.intRed,0,255);
    enforceRange(recPixel.intGreen,0,255);
    enforceRange(recPixel.intBlue,0,255);
    _image[intRow][intCol]=recPixel;
}

void UJImage::enforceRange(int intValue,int intMin,int intMax) const{
    if(intValue<intMin || intValue>intMax){
        std::cerr<<"ERROR! "<<intValue<<" must be in ["<<intMin<<","<<intMax<<"]\n";

	}  
}

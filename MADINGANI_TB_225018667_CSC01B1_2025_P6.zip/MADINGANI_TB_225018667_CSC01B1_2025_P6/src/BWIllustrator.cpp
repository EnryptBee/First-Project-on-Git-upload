
module;

#include <sstream>
#include <string>

export module BWIllustrator;

import LibUtility;
import FlagIllustrator;

export class BWIllustrator : public FlagIllustrator {
public:
    BWIllustrator();
    BWIllustrator(int,int);

    std::string exportImage() const override;
	std::string illustrate(FlagType eType) override;

private:
    bool isWhite(UJPixel recPixel) const;
	
};

BWIllustrator::BWIllustrator():FlagIllustrator(){}
BWIllustrator::BWIllustrator(int h,int w):FlagIllustrator(h,w){}
//overriding the pure virtual base
std::string BWIllustrator::illustrate(FlagType eType) {
    return FlagIllustrator::illustrate(eType); // reuse base drawing logic   
}


std::string BWIllustrator::exportImage() const {
    std::stringstream ss;
    ss<<"P1\n"<<_image->getWidth()<<" "<<_image->getHeight()<<"\n";
    for(int r=0;r<_image->getHeight();r++){
        for(int c=0;c<_image->getWidth();c++){
            int v=isWhite(_image->getPixel(r,c))?0:1;
            ss<<v<<" ";
        }
        ss<<"\n";
    }
    return ss.str();
}
bool BWIllustrator::isWhite(UJPixel recPixel) const {
    return (recPixel.intRed==255) &&(recPixel.intGreen==255) && (recPixel.intBlue==255);
}

module;

#include <cassert>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <string>

export module FlagIllustrator;

import LibUtility;
import UJImage;

export class FlagIllustrator {
public:
    FlagIllustrator();
    FlagIllustrator(int intHeight, int intWidth);
    FlagIllustrator(const FlagIllustrator& objOriginal);
    virtual ~FlagIllustrator();

    virtual std::string exportImage() const;
	
	//pure virtual function generate image to default is P3 

    virtual std:: string illustrate(FlagType eType) =0;

    static constexpr int DEF_HEIGHT = 480;
    static constexpr int DEF_WIDTH = 640;

protected:
    UJImage* _image;

private:
    void drawAuFlag();
    void drawJPFlag();
    void drawNGFlag();
    double distance(int intY1, int intY2, int intX1, int intX2) const;
    void alloc(int intRows, int intCols);
    void clone(const FlagIllustrator& objOriginal);
    void dealloc();
    void enforceRange(int intArg, int intMin, int intMax) const;
};

// Constructors
FlagIllustrator::FlagIllustrator() : FlagIllustrator(DEF_HEIGHT, DEF_WIDTH) {}



FlagIllustrator::FlagIllustrator(int intHeight, int intWidth) {
    enforceRange(intHeight, 0, 10000);
    enforceRange(intWidth, 0, 10000);
    alloc(intHeight, intWidth);
}

FlagIllustrator::FlagIllustrator(const FlagIllustrator& objOriginal)
    : FlagIllustrator(objOriginal._image->getHeight(), objOriginal._image->getWidth()) {
    clone(objOriginal);
}

FlagIllustrator::~FlagIllustrator() { dealloc(); }

// Export default P3
std::string FlagIllustrator::exportImage() const {
    return _image->toPPM();
}

// Draw flag based on type
 std:: string FlagIllustrator::illustrate(FlagType eType) {
    switch (eType) {
        case AUSTRIA: drawAuFlag(); break;
        case JAPAN:   drawJPFlag(); break;
        case NIGERIA: drawNGFlag(); break;
		default:
		return "Uknown Flagtype";
    }
	return "Flag drawn successfully";
}

// Austria
void FlagIllustrator::drawAuFlag() {
    int intThickness = _image->getHeight() / 3;
    UJPixel recRed   = {239, 51, 64};
    UJPixel recWhite = {255, 255, 255};

    for (int r = 0; r < _image->getHeight(); r++) {
        for (int c = 0; c < _image->getWidth(); c++) {
            if (r > intThickness && r < intThickness * 2)
                _image->setPixel(r, c, recWhite);
            else
                _image->setPixel(r, c, recRed);
        }
    }
}

// Japan
void FlagIllustrator::drawJPFlag() {
    UJPixel recRed   = {188, 0, 45};
    UJPixel recWhite = {255, 255, 255};
    double dblRadius = 0.3 * static_cast<double>(_image->getHeight());
    int intCR = _image->getHeight() / 2;
    int intCC = _image->getWidth() / 2;

    for (int r = 0; r < _image->getHeight(); r++) {
        for (int c = 0; c < _image->getWidth(); c++) {
            if (distance(r, intCR, c, intCC) <= dblRadius)
                _image->setPixel(r, c, recRed);
            else
                _image->setPixel(r, c, recWhite);
        }
    }
}

// Nigeria
void FlagIllustrator::drawNGFlag() {
    int intThickness = _image->getWidth() / 3;
    UJPixel recGreen = {27, 115, 57};
    UJPixel recWhite = {255, 255, 255};

    for (int r = 0; r < _image->getHeight(); r++) {
        for (int c = 0; c < _image->getWidth(); c++) {
            if (c > intThickness && c < intThickness * 2)
                _image->setPixel(r, c, recWhite);
            else
                _image->setPixel(r, c, recGreen);
        }
    }
}

// helper
double FlagIllustrator::distance(int intY1, int intY2, int intX1, int intX2) const {
    return sqrt(pow(intX2 - intX1, 2) + pow(intY2 - intY1, 2));
}

// Memory allocation
void FlagIllustrator::alloc(int intHeight, int intWidth) {
    _image = new UJImage(intHeight, intWidth);
}

// Clone
void FlagIllustrator::clone(const FlagIllustrator& objOriginal) {
    for (int r = 0; r < _image->getHeight(); r++)
        for (int c = 0; c < _image->getWidth(); c++)
            _image->setPixel(r, c, objOriginal._image->getPixel(r, c));
}

// Free memory
void FlagIllustrator::dealloc() {
    delete _image;
}

// Range check
void FlagIllustrator::enforceRange(int intArg, int intMin, int intMax) const {
    if (intArg < intMin || intArg > intMax) {
        std::cerr << intArg << " must be in [" << intMin << ", " << intMax << "]\n";
        exit(ERROR_RANGE);
    }
}

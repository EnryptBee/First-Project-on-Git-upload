package acsse.csc2b.server;
/**
 * @version PO04-TakeHome
 * @author Miss Madingani TB
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import java.util.StringTokenizer;

public class ImgHandler {
	private Socket incomingConnection;
	private OutputStream os;
	private InputStream is;
	private PrintWriter pw;
	private BufferedReader br;
	private DataOutputStream dos;
	private DataInputStream dis;
	
	public ImgHandler(Socket s) {
		this.incomingConnection = s;
		try { 
			os = incomingConnection.getOutputStream();
			is = incomingConnection.getInputStream();
			pw = new PrintWriter(os);
			br = new BufferedReader(new InputStreamReader(is));
			dos = new DataOutputStream(os);
			dis = new DataInputStream(is);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
/**
 * 
 * @throws IOException
 */

	public void run() throws IOException {
		System.out.println("Handling Client Requests");
		
		try {
			
		String command;
		
		while((command =br.readLine())!=null)
		{
			System.out.println("Received: "+command);
		//Command:List Returns list of images
			if(command.equals("LIST"))
			{ 
				String list = loadImgList();
			
				pw.print(list);
				pw.println("END");
				pw.flush();
			}
			else if(command.startsWith("DOWN"))
			{
				String[] parts = command.split(" ");
				if(parts.length == 2)
				{
					String id = parts[1];
					handleDownload(id);
					
				}
			}
				else if(command.startsWith("UP"))
				{
					String[] parts = command.split(" ");
					if(parts.length == 4)
					{
						int id = Integer.parseInt(parts[1]);
						String name = parts[2];
						long size = Long.parseLong(parts[3]);
						handleUpload(id,name,size);
						
					}
				}
				else
				{
					pw.println("Error:Unknown command");
					pw.flush();	
			}
		}
		
	}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(incomingConnection!=null)
			{
				incomingConnection.close();
				System.out.println("Client disconnected");
			}
		}
	}

	
	private void handleDownload(String id) throws FileNotFoundException {
		//GetFileName from ID
		String filename = getFileNameFromID(id);
		
		if(filename.isEmpty())
		{
			pw.println("ERROR: Image not found for ID"+id);
			pw.flush();
			return;
			
		}
		File file = new File("data/server/"+filename);
		
		if(!file.exists())
		{
			pw.println("ERROR:File not found");
			pw.flush();
			return;
			
		}
		
		//Send file size first as text
		pw.println("OK "+file.length()+" "+filename);
		pw.flush();
		
		//
		//Send the actual fileas binary
		FileInputStream fis= new FileInputStream(file);
		byte[] buffer = new byte[2024];
		int bytesRead;
		
		try {
			while((bytesRead =fis.read(buffer))!=-1)
			{
				dos.write(buffer,0,bytesRead);
				dos.flush();
				
			}
			fis.close();
			
			System.out.println("Sent image: "+ filename);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
				
				//Send 
		
	


	private void handleUpload(int id, String name, long size) throws FileNotFoundException 
	{
		//Create fileNAME
		String filename = id +"_"+name;
		
		//Check if ID already exists
		String existingFile = getFileNameFromID(String.valueOf(id));
	    if (!existingFile.isEmpty()) 
		{
			pw.println("FAILURE:ID ALREADY exits");
			pw.flush();
			return;
			
		}
	    
		//save the image file
		File file = new File("data/server/"+filename);
		FileOutputStream fos = new FileOutputStream(file);
		
		byte[] buffer = new byte[1024];
		int bytesRead;
		int totalRead =0;
		
		
		try {
			while(totalRead <size )
			{
				bytesRead=dis.read(buffer);
				if(bytesRead ==-1)
					break;
				
				fos.write(buffer,0,bytesRead);
				totalRead +=bytesRead;
				
				
			}
			fos.close();
			addToImageList(id,filename);
			pw.println("SUCCESS");
			pw.flush();
			
			
		
			System.out.println("Upload image: "+ filename);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	private void addToImageList(int id, String filename)
	{
		try {
			FileWriter fw = new FileWriter("data/server/ImgList.txt",true);
			fw.write(id+" "+filename+"\n");
			fw.close();
			
		} catch (IOException e) {
			System.out.println("Error adding to image list");
			e.printStackTrace();
		}
		
					
				}


	private String getFileNameFromID(String searchID) throws FileNotFoundException
	{
		String ret = "";
		File imglist = new File("data/server/ImgList.txt");
		try {
			Scanner scanner = new Scanner(imglist);
			while(scanner.hasNextLine())
			{
				
				String line = scanner.nextLine();
			String[] parts = line.split(" ");
			if(parts.length==2&& parts[0].equals(searchID))
			{
				ret= parts[1];
				break;
			}
			}
			scanner.close();
		}finally
		{
			
		}
		
		return ret;
	}
	
	//Marks for Returning of image files list
	private String loadImgList() throws FileNotFoundException {
		String ret = "";
		
		File imglist= new File("data/server/ImgList.txt");
		
		try {
			Scanner scanner = new Scanner(imglist);
			while(scanner.hasNextLine())
			{
				String line = scanner.nextLine();
				
				ret+= line +"\n";
				
			}
			scanner.close();
		}
		finally
		{
			
		}
		
		return ret; 
	}

}

package acsse.csc2b.server;
/**
 * @version PO04-TakeHome
 * @author Miss Madingani TB
 */

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ImgServer {

	private ServerSocket server;
	private boolean running=true;
	
	public ImgServer(int port) throws IOException 
	{
		//creating a new server
		server= new ServerSocket(port);
		System.out.println("Server started on port"+port);
		running = true;
		startServer();
		new Thread (this::startServer).start();
		
	}

	private void startServer() {
		// TODO - multi-threaded server
		System.out.println("Starting the server...");
		System.out.println("Waiting for connections...");
		
		while(true)
		{
			
			try {
				Socket client=null;
				try {
					client = server.accept();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			
			System.out.println("Client connected:"+client.getInetAddress());
			
			ImgHandler handler = new ImgHandler(client);
			
			Thread t= new Thread (() ->{
				try {
					
				
					handler.run();
				}
				 catch (IOException e)
				{
					 e.printStackTrace();
				}
			});
			t.start(); //don't forget to start the thread
			}
			
			finally
			{
				
			}
			
		}
		
		
		
		
	}
	
	public static void main(String[] args) {
		try {
			
			//Starting the server
			ImgServer s = new ImgServer(5432 );
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

package acsse.csc2b.client;
/**
 * @version PO04-TakeHome
 * @author Miss Madingani TB
 */

import java.io.IOException;



import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class ImgClient  extends Application
{
	
	public static void main(String[] args) {
		launch(args);
	}
	
	@Override
	public void start(Stage primaryStage) 
	{
		try
		{
			//Creating the Graphical User Interface
			ImgClientPane root = new ImgClientPane(primaryStage);
			Scene scene = new Scene(root,800,600);
			primaryStage.setTitle("Image Client");
			primaryStage.setScene(scene);
			primaryStage.show();
			
		}
		finally
		{
			
		}
	}
}

package acsse.csc2b.client;
/**
 * @version PO04-TakeHome
 * @author Miss Madingani TB
 * The Image Client Pane 
 * 
 */

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.StringTokenizer;
import java.util.concurrent.atomic.AtomicInteger;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class ImgClientPane extends GridPane {
	
	private Socket socket;
	private InputStream is;
	private OutputStream os;
	private PrintWriter pw;
	private BufferedReader br;
	private DataInputStream dis;
	private DataOutputStream dos;
	private String[] listData;
	
	//GUI:
	private Button btnConnect ;
	private Button btnPULL ;
	private TextField txtIDToRetrieve;
	private Label lblID ;
	private Button btnDownload;
	private Button btnUpload;
	TextArea listArea;
	private TextArea responseArea;
	private Label lblList;
	private Label lblResponse;
	private ImageView imgView ;
	private Button btnDisplay;
	private String fileToGetName ="";
	private AtomicInteger  idCounter=new AtomicInteger(1);
	
	/**
	 * The ImgaeClientPane
	 * @throws IOException
	 * @param stage
	 * 
	 */
	public ImgClientPane(Stage stage) 
	{
		setupUI();
		
		
		btnConnect.setOnAction((e)->{
			try {
				socket = new Socket("localhost",5432);
				
				os = socket.getOutputStream();
				is = socket.getInputStream();
				
				br = new BufferedReader(new InputStreamReader(is));
				pw  =new PrintWriter(os);
				
				
				dis = new DataInputStream(is);
				dos = new DataOutputStream(os);
				
				//do
				responseArea.appendText("Connected to server!\n");
				
			} catch (IOException e1) 
			{
				responseArea.appendText("Connection Faield:"+e1.getMessage());
				e1.printStackTrace();
			}
		});
		
		//PULL BUTTON 
		//"LIST the server returns a list
		btnPULL.setOnAction((e)->{
			if(pw == null)
			{
				responseArea.appendText("Connect to Server");
				return;
			}
			try {
				//Send the list command to server 
				
				pw.println("LIST");
				pw.flush();
				
				listArea.clear();
				String response;
				//Reading until server sends "END" to signal
				try {
					while(!(response = br.readLine()).equals("END"))
					{
						listArea.appendText((response +"\n"));
						
					}
					responseArea.appendText("Image list is received");
					
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					responseArea.appendText("Did not get list"+e1.getMessage()+"\n");
					
					e1.printStackTrace();
				}
			}
			finally 
			{
				
			}
			
		});
		

		btnDownload.setOnAction((e)->{
			// TODO - Retrieving image file
			if(pw==null)
			{
				responseArea.appendText("Connect to server"+"\n");
				
				return;
				
			}
			
			String id= txtIDToRetrieve.getText();
			
			if(id.isEmpty())
			{
				responseArea.appendText("Please enter an ID"+"\n");
				return;
			}
			
			try {
				pw.println("DOWN "+id);
				pw.flush();
				
				//Read server response(File size error)
				String response = br.readLine();
				
				if(response.startsWith("ERROR"))
				{
					responseArea.appendText(response+"\n");
					return;
					
				}
				
				//parsing file from Ok 
				String[] parts = response.split(" ");
				
				long fileSize =Long.parseLong(parts[1]);
				
				fileToGetName ="data/client/"+id;
				File file = new File(fileToGetName);
				FileOutputStream fos = new FileOutputStream(file);
				
				
				byte[] buffer = new byte[1024];
				int bytesRead;
				long totalRead =0;
				
				while(totalRead <fileSize)
				{
					bytesRead = dis.read(buffer);
					if(bytesRead ==-1)
						break;
					fos.write(buffer,0,bytesRead);
					totalRead += bytesRead;
					
				}
				fos.close();
				
				responseArea.appendText("Dowload image "+id+ fileSize+"bytes\n");
				
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				responseArea.appendText("Dowload Error :"+e1.getLocalizedMessage()+"\n");
				e1.printStackTrace();
			}finally
			{
				
			}
			
			
		});
		
		
		btnUpload.setOnAction((e)->{
			// TODO - Uploading an image file
			
			if(pw == null)
			{
				responseArea.appendText("Connect to the server");
				return;
				
			}
			FileChooser fileChooser = new FileChooser();
			fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Images","*.jpg","*.png","*.jpeg")); 
		
			File file = fileChooser.showOpenDialog(null);
			if (file ==null)
		{
			responseArea.appendText("No file selected");
			
		}
			try {
				//Generating an Id(usign a timeStamp
				
				int id = idCounter.getAndIncrement(); // sequential ID
				String name = file.getName();
				long size = file.length();
                 pw.println("UP "+id + " " + name + " " + size);
                 pw.flush();
                 
              FileInputStream fis = new FileInputStream(file);
              byte[] buffer = new byte[1024];
              int bytesRead;
              
              while((bytesRead = fis.read(buffer))!=-1)
              {
            	  dos.write(buffer,0,bytesRead);
            	  dos.flush();
            	  
              }
              try {
				fis.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
              
              String response = br.readLine();
              responseArea.appendText("Upload"+response+"\n");
              
              
			} catch (IOException e1) {
				
				e1.printStackTrace();
			}
			finally
			{
				
			}
			
		
		
		});
		

		btnDisplay.setOnAction((e)->{
			// TODO - Display of image file
			if(fileToGetName.isEmpty())
			{
				responseArea.appendText("Please download an image first");
				return;
				
			}
			//fileToGetName ="data/client/" + ".jpg";
			Image image = new Image("file:"+fileToGetName);
			
			
			imgView.setImage(image);
			responseArea.appendText("Image displayed:"+fileToGetName+"\n");
			
			

		});
		
	
	}
	private void setupUI() {
	    VBox root = new VBox(20); // spacing between elements
	    root.setAlignment(Pos.CENTER);

	    // Buttons
	    
	    btnConnect = new Button("Connect to Server");
	    btnUpload = new Button("Upload Image");
	    btnPULL = new Button("Pull List");
	    btnDownload = new Button("Download Image");
	    btnDisplay = new Button("Display Image");

	    // Text areas and fields
	    
	    listArea = new TextArea();
	    listArea.setPrefHeight(150);
	    listArea.setPrefWidth(300);

	    lblID = new Label("Enter ID");
	    txtIDToRetrieve = new TextField();
	    txtIDToRetrieve.setPrefColumnCount(40);

	    imgView = new ImageView();
	    imgView.setFitHeight(300);
	    imgView.setFitWidth(300);

	    lblResponse = new Label("Status:");
	    responseArea = new TextArea();
	    responseArea.setPrefHeight(150);
	    responseArea.setPrefWidth(400);

	    // Add everything in order
	    
	    
	    root.getChildren().addAll(
	        btnConnect,
	        btnUpload,
	        btnPULL, listArea,
	        lblID, txtIDToRetrieve, btnDownload,
	        btnDisplay, imgView,
	        lblResponse, responseArea
	    );
     
	 // attach VBox to your GridPane (or directly use VBox as root
	    this.getChildren().add(root); 
	}
	

	
	
	private String readResponse(BufferedReader br)
	{
		String response = "";
		try {
			response= br.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return response;
	}
	
	private void sendCommand(PrintWriter pw, String msg)
	{
		pw.println(msg);
		pw.flush();
	}
	

}
